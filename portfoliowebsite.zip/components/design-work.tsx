"use client"

import { Card } from "@/components/ui/card"
import { Instagram, Palette, Sparkles } from "lucide-react"

export default function DesignWork() {
  const designProjects = [
    {
      title: "Visual Identity - Tech Startup",
      description: "Complete branding including logo, color palette and style guide",
      image: "/modern-tech-logo-branding-blue.jpg",
      category: "Visual Identity",
      icon: Palette,
    },
    {
      title: "Social Media - Fashion Brand",
      description: "Visual content creation for Instagram and Facebook",
      image: "/fashion-social-media-post-modern.jpg",
      category: "Social Media",
      icon: Instagram,
    },
    {
      title: "Visual Identity - Restaurant",
      description: "Logo, menu and marketing materials",
      image: "/restaurant-branding-elegant-dark.jpg",
      category: "Visual Identity",
      icon: Palette,
    },
    {
      title: "Social Media - Fitness Brand",
      description: "Posts, stories and templates for social media",
      image: "/fitness-instagram-post-energetic.jpg",
      category: "Social Media",
      icon: Instagram,
    },
    {
      title: "Branding - Digital Agency",
      description: "Complete visual identity and institutional material",
      image: "/digital-agency-branding-modern-blue.jpg",
      category: "Visual Identity",
      icon: Sparkles,
    },
    {
      title: "Social Media - E-commerce",
      description: "Visual campaigns for product launches",
      image: "/ecommerce-product-social-media.jpg",
      category: "Social Media",
      icon: Instagram,
    },
  ]

  return (
    <section id="design" className="py-24 md:py-32 bg-gradient-blue">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Design <span className="text-primary">Work</span>
            </h2>
            <p className="text-xl text-muted-foreground">Visual identity and social media content</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {designProjects.map((project, index) => (
              <Card
                key={index}
                className="overflow-hidden bg-card border-border hover:border-primary/50 transition-all duration-300 group cursor-pointer"
              >
                <div className="relative overflow-hidden aspect-square">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                    <div className="flex items-center gap-2 text-primary">
                      {project.icon && <project.icon className="h-5 w-5" />}
                      <span className="text-sm font-medium">{project.category}</span>
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground text-sm">{project.description}</p>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
