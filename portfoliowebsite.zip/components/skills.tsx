"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { useLanguage } from "@/contexts/language-context"

export default function Skills() {
  const [activeCategory, setActiveCategory] = useState("development")
  const { t } = useLanguage()

  const categories = {
    development: [
      { name: "React / Next.js", level: 95 },
      { name: "TypeScript", level: 90 },
      { name: "Node.js", level: 85 },
      { name: "Tailwind CSS", level: 95 },
      { name: "PostgreSQL", level: 80 },
      { name: "Git / GitHub", level: 90 },
    ],
    design: [
      { name: "Figma", level: 95 },
      { name: "Adobe Photoshop", level: 90 },
      { name: "Adobe Illustrator", level: 85 },
      { name: "Visual Identity", level: 90 },
      { name: "Social Media", level: 95 },
      { name: "UI/UX Design", level: 88 },
    ],
  }

  return (
    <section id="habilidades" className="py-24 md:py-32 bg-gradient-blue">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              {t.skills.title} <span className="text-primary">{t.skills.titleHighlight}</span>
            </h2>
            <p className="text-xl text-muted-foreground">{t.skills.subtitle}</p>
          </div>

          <div className="flex justify-center gap-4 mb-12">
            <button
              onClick={() => setActiveCategory("development")}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                activeCategory === "development"
                  ? "bg-primary text-primary-foreground glow-blue"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.skills.development}
            </button>
            <button
              onClick={() => setActiveCategory("design")}
              className={`px-6 py-3 rounded-lg font-medium transition-all ${
                activeCategory === "design"
                  ? "bg-primary text-primary-foreground glow-blue"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.skills.design}
            </button>
          </div>

          <Card className="p-8 bg-card border-border">
            <div className="space-y-6">
              {categories[activeCategory as keyof typeof categories].map((skill, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{skill.name}</span>
                    <span className="text-sm text-muted-foreground">{skill.level}%</span>
                  </div>
                  <div className="h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full transition-all duration-1000 ease-out"
                      style={{ width: `${skill.level}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </section>
  )
}
