"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Github } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

export default function Projects() {
  const [filter, setFilter] = useState("all")
  const { t } = useLanguage()

  const projects = [
    {
      title: t.projects.project1.title,
      description: t.projects.project1.description,
      image: "/modern-ecommerce-website-dark-blue.jpg",
      tags: ["Next.js", "TypeScript", "Stripe"],
      category: "web",
      github: "#",
      demo: "#",
    },
    {
      title: t.projects.project2.title,
      description: t.projects.project2.description,
      image: "/analytics-dashboard-dark-theme-blue.jpg",
      tags: ["React", "D3.js", "Node.js"],
      category: "web",
      github: "#",
      demo: "#",
    },
    {
      title: t.projects.project3.title,
      description: t.projects.project3.description,
      image: "/fitness-mobile-app-dark-blue.jpg",
      tags: ["React Native", "Firebase"],
      category: "mobile",
      github: "#",
      demo: "#",
    },
    {
      title: t.projects.project4.title,
      description: t.projects.project4.description,
      image: "/saas-landing-page-modern-blue.jpg",
      tags: ["Next.js", "Tailwind", "Framer Motion"],
      category: "web",
      github: "#",
      demo: "#",
    },
  ]

  const filteredProjects = filter === "all" ? projects : projects.filter((p) => p.category === filter)

  return (
    <section id="projetos" className="py-24 md:py-32 bg-gradient-blue">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              {t.projects.title} <span className="text-primary">{t.projects.titleHighlight}</span>
            </h2>
            <p className="text-xl text-muted-foreground">{t.projects.subtitle}</p>
          </div>

          <div className="flex justify-center gap-4 mb-12 flex-wrap">
            <button
              onClick={() => setFilter("all")}
              className={`px-6 py-2 rounded-lg font-medium transition-all capitalize ${
                filter === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.projects.all}
            </button>
            <button
              onClick={() => setFilter("web")}
              className={`px-6 py-2 rounded-lg font-medium transition-all capitalize ${
                filter === "web"
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.projects.web}
            </button>
            <button
              onClick={() => setFilter("mobile")}
              className={`px-6 py-2 rounded-lg font-medium transition-all capitalize ${
                filter === "mobile"
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.projects.mobile}
            </button>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {filteredProjects.map((project, index) => (
              <Card
                key={index}
                className="overflow-hidden bg-card border-border hover:border-primary/50 transition-all duration-300 group"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6 gap-4">
                    <Button size="sm" variant="secondary" asChild>
                      <a href={project.github} target="_blank" rel="noopener noreferrer">
                        <Github className="h-4 w-4 mr-2" />
                        {t.projects.code}
                      </a>
                    </Button>
                    <Button size="sm" asChild>
                      <a href={project.demo} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        {t.projects.demo}
                      </a>
                    </Button>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-muted-foreground mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, i) => (
                      <span key={i} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
