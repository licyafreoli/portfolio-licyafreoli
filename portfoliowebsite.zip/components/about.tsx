"use client"

import { Code2, Palette, Rocket, Users } from "lucide-react"
import { Card } from "@/components/ui/card"
import { useLanguage } from "@/contexts/language-context"

export default function About() {
  const { t } = useLanguage()

  const highlights = [
    {
      icon: Code2,
      title: t.about.development.title,
      description: t.about.development.description,
    },
    {
      icon: Palette,
      title: t.about.design.title,
      description: t.about.design.description,
    },
    {
      icon: Rocket,
      title: t.about.performance.title,
      description: t.about.performance.description,
    },
    {
      icon: Users,
      title: t.about.collaboration.title,
      description: t.about.collaboration.description,
    },
  ]

  return (
    <section id="sobre" className="py-24 md:py-32 bg-gradient-blue">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              {t.about.title} <span className="text-primary">{t.about.titleHighlight}</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">{t.about.description}</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((item, index) => (
              <Card
                key={index}
                className="p-6 bg-card border-border hover:border-primary/50 transition-all duration-300 hover:scale-105 hover:glow-blue group"
              >
                <div className="mb-4 inline-flex p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                  <item.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
