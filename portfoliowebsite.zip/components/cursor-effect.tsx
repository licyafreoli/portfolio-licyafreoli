"use client"

import { useEffect, useState } from "react"

export default function CursorEffect() {
  const [mousePosition, setMousePosition] = useState({ x: -100, y: -100 })
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
      setIsVisible(true)
    }

    const handleMouseLeave = () => {
      setIsVisible(false)
    }

    window.addEventListener("mousemove", handleMouseMove)
    document.addEventListener("mouseleave", handleMouseLeave)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
      document.removeEventListener("mouseleave", handleMouseLeave)
    }
  }, [])

  return (
    <>
      {/* Cursor principal - bolinha branca */}
      <div
        className="pointer-events-none fixed z-[9999] rounded-full bg-white mix-blend-difference"
        style={{
          left: `${mousePosition.x}px`,
          top: `${mousePosition.y}px`,
          width: "16px",
          height: "16px",
          transform: "translate(-50%, -50%)",
          transition: "width 0.2s ease, height 0.2s ease",
          opacity: isVisible ? 1 : 0,
        }}
      />

      {/* Efeito de glow branco - halo ao redor do cursor */}
      <div
        className="pointer-events-none fixed z-[9998] rounded-full"
        style={{
          left: `${mousePosition.x}px`,
          top: `${mousePosition.y}px`,
          width: "300px",
          height: "300px",
          transform: "translate(-50%, -50%)",
          background: "radial-gradient(circle, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 30%, transparent 70%)",
          transition: "all 0.15s ease-out",
          opacity: isVisible ? 1 : 0,
        }}
      />

      {/* Efeito de trilha - bolinha menor que segue */}
      <div
        className="pointer-events-none fixed z-[9997] rounded-full bg-white/60"
        style={{
          left: `${mousePosition.x}px`,
          top: `${mousePosition.y}px`,
          width: "8px",
          height: "8px",
          transform: "translate(-50%, -50%)",
          transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
          opacity: isVisible ? 0.6 : 0,
        }}
      />
    </>
  )
}
