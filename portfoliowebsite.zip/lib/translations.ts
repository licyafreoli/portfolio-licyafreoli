export const translations = {
  en: {
    nav: {
      home: "Home",
      about: "About",
      skills: "Skills",
      projects: "Projects",
      design: "Design",
      contact: "Contact",
    },
    hero: {
      badge: "Developer & Designer",
      title: "Creating unique",
      titleHighlight: "digital experiences",
      description:
        "Full-stack developer and designer specialized in visual identity and social media. Transforming ideas into extraordinary digital products.",
      viewProjects: "View Projects",
      getInTouch: "Get in Touch",
    },
    about: {
      title: "About",
      titleHighlight: "Me",
      description:
        "I'm a professional passionate about creating digital experiences that combine clean code with impeccable design. With years of experience in development and design, I help brands and businesses stand out in the digital world.",
      development: {
        title: "Development",
        description: "Expert in React, Next.js, TypeScript and Node.js",
      },
      design: {
        title: "Design",
        description: "Visual identity, branding and social media design",
      },
      performance: {
        title: "Performance",
        description: "Focus on optimization and user experience",
      },
      collaboration: {
        title: "Collaboration",
        description: "Teamwork and effective communication",
      },
    },
    skills: {
      title: "My",
      titleHighlight: "Skills",
      subtitle: "Technologies and tools I master",
      development: "Development",
      design: "Design",
    },
    projects: {
      title: "Development",
      titleHighlight: "Projects",
      subtitle: "Some of my most recent work",
      all: "All",
      web: "Web",
      mobile: "Mobile",
      code: "Code",
      demo: "Demo",
      project1: {
        title: "E-commerce Platform",
        description: "Complete e-commerce platform with Next.js, Stripe and PostgreSQL",
      },
      project2: {
        title: "Analytics Dashboard",
        description: "Interactive dashboard with real-time charts and data visualization",
      },
      project3: {
        title: "Fitness Mobile App",
        description: "Fitness app with exercise and nutrition tracking",
      },
      project4: {
        title: "SaaS Landing Page",
        description: "Modern and responsive landing page for SaaS product",
      },
    },
    contact: {
      title: "Get in",
      titleHighlight: "Touch",
      subtitle: "Let's work together on your next project",
      info: "Contact Information",
      email: "Email",
      phone: "Phone",
      location: "Location",
      available: "Available for Projects",
      availableText:
        "I'm always open to discussing new projects, creative ideas or opportunities to be part of your vision.",
      availableNow: "Available now",
      form: {
        name: "Name",
        namePlaceholder: "Your name",
        email: "Email",
        emailPlaceholder: "your@email.com",
        message: "Message",
        messagePlaceholder: "Tell me about your project...",
        send: "Send Message",
      },
      footer: {
        rights: "All rights reserved.",
        built: "Built with Next.js and Tailwind CSS",
      },
    },
  },
  pt: {
    nav: {
      home: "Início",
      about: "Sobre",
      skills: "Habilidades",
      projects: "Projetos",
      design: "Design",
      contact: "Contato",
    },
    hero: {
      badge: "Desenvolvedor & Designer",
      title: "Criando experiências",
      titleHighlight: "digitais únicas",
      description:
        "Desenvolvedor full-stack e designer especializado em identidade visual e social media. Transformando ideias em produtos digitais extraordinários.",
      viewProjects: "Ver Projetos",
      getInTouch: "Entre em Contato",
    },
    about: {
      title: "Sobre",
      titleHighlight: "Mim",
      description:
        "Sou um profissional apaixonado por criar experiências digitais que combinam código limpo com design impecável. Com anos de experiência em desenvolvimento e design, ajudo marcas e empresas a se destacarem no mundo digital.",
      development: {
        title: "Desenvolvimento",
        description: "Expert em React, Next.js, TypeScript e Node.js",
      },
      design: {
        title: "Design",
        description: "Identidade visual, branding e design para redes sociais",
      },
      performance: {
        title: "Performance",
        description: "Foco em otimização e experiência do usuário",
      },
      collaboration: {
        title: "Colaboração",
        description: "Trabalho em equipe e comunicação eficaz",
      },
    },
    skills: {
      title: "Minhas",
      titleHighlight: "Habilidades",
      subtitle: "Tecnologias e ferramentas que domino",
      development: "Desenvolvimento",
      design: "Design",
    },
    projects: {
      title: "Projetos de",
      titleHighlight: "Desenvolvimento",
      subtitle: "Alguns dos meus trabalhos mais recentes",
      all: "Todos",
      web: "Web",
      mobile: "Mobile",
      code: "Código",
      demo: "Demo",
      project1: {
        title: "Plataforma E-commerce",
        description: "Plataforma completa de e-commerce com Next.js, Stripe e PostgreSQL",
      },
      project2: {
        title: "Dashboard de Analytics",
        description: "Dashboard interativo com gráficos em tempo real e visualização de dados",
      },
      project3: {
        title: "App Mobile de Fitness",
        description: "App de fitness com rastreamento de exercícios e nutrição",
      },
      project4: {
        title: "Landing Page SaaS",
        description: "Landing page moderna e responsiva para produto SaaS",
      },
    },
    contact: {
      title: "Entre em",
      titleHighlight: "Contato",
      subtitle: "Vamos trabalhar juntos no seu próximo projeto",
      info: "Informações de Contato",
      email: "Email",
      phone: "Telefone",
      location: "Localização",
      available: "Disponível para Projetos",
      availableText:
        "Estou sempre aberto para discutir novos projetos, ideias criativas ou oportunidades de fazer parte da sua visão.",
      availableNow: "Disponível agora",
      form: {
        name: "Nome",
        namePlaceholder: "Seu nome",
        email: "Email",
        emailPlaceholder: "seu@email.com",
        message: "Mensagem",
        messagePlaceholder: "Conte-me sobre seu projeto...",
        send: "Enviar Mensagem",
      },
      footer: {
        rights: "Todos os direitos reservados.",
        built: "Construído com Next.js e Tailwind CSS",
      },
    },
  },
  it: {
    nav: {
      home: "Home",
      about: "Chi Sono",
      skills: "Competenze",
      projects: "Progetti",
      design: "Design",
      contact: "Contatto",
    },
    hero: {
      badge: "Sviluppatore & Designer",
      title: "Creando esperienze",
      titleHighlight: "digitali uniche",
      description:
        "Sviluppatore full-stack e designer specializzato in identità visiva e social media. Trasformo idee in prodotti digitali straordinari.",
      viewProjects: "Vedi Progetti",
      getInTouch: "Contattami",
    },
    about: {
      title: "Chi",
      titleHighlight: "Sono",
      description:
        "Sono un professionista appassionato di creare esperienze digitali che combinano codice pulito con design impeccabile. Con anni di esperienza nello sviluppo e nel design, aiuto marchi e aziende a distinguersi nel mondo digitale.",
      development: {
        title: "Sviluppo",
        description: "Esperto in React, Next.js, TypeScript e Node.js",
      },
      design: {
        title: "Design",
        description: "Identità visiva, branding e design per social media",
      },
      performance: {
        title: "Performance",
        description: "Focus su ottimizzazione ed esperienza utente",
      },
      collaboration: {
        title: "Collaborazione",
        description: "Lavoro di squadra e comunicazione efficace",
      },
    },
    skills: {
      title: "Le Mie",
      titleHighlight: "Competenze",
      subtitle: "Tecnologie e strumenti che padroneggio",
      development: "Sviluppo",
      design: "Design",
    },
    projects: {
      title: "Progetti di",
      titleHighlight: "Sviluppo",
      subtitle: "Alcuni dei miei lavori più recenti",
      all: "Tutti",
      web: "Web",
      mobile: "Mobile",
      code: "Codice",
      demo: "Demo",
      project1: {
        title: "Piattaforma E-commerce",
        description: "Piattaforma e-commerce completa con Next.js, Stripe e PostgreSQL",
      },
      project2: {
        title: "Dashboard Analitica",
        description: "Dashboard interattiva con grafici in tempo reale e visualizzazione dati",
      },
      project3: {
        title: "App Mobile Fitness",
        description: "App fitness con tracciamento esercizi e nutrizione",
      },
      project4: {
        title: "Landing Page SaaS",
        description: "Landing page moderna e responsive per prodotto SaaS",
      },
    },
    contact: {
      title: "Mettiti in",
      titleHighlight: "Contatto",
      subtitle: "Lavoriamo insieme al tuo prossimo progetto",
      info: "Informazioni di Contatto",
      email: "Email",
      phone: "Telefono",
      location: "Posizione",
      available: "Disponibile per Progetti",
      availableText:
        "Sono sempre aperto a discutere nuovi progetti, idee creative o opportunità di far parte della tua visione.",
      availableNow: "Disponibile ora",
      form: {
        name: "Nome",
        namePlaceholder: "Il tuo nome",
        email: "Email",
        emailPlaceholder: "tua@email.com",
        message: "Messaggio",
        messagePlaceholder: "Parlami del tuo progetto...",
        send: "Invia Messaggio",
      },
      footer: {
        rights: "Tutti i diritti riservati.",
        built: "Realizzato con Next.js e Tailwind CSS",
      },
    },
  },
  fr: {
    nav: {
      home: "Accueil",
      about: "À Propos",
      skills: "Compétences",
      projects: "Projets",
      design: "Design",
      contact: "Contact",
    },
    hero: {
      badge: "Développeur & Designer",
      title: "Créant des expériences",
      titleHighlight: "numériques uniques",
      description:
        "Développeur full-stack et designer spécialisé en identité visuelle et médias sociaux. Je transforme les idées en produits numériques extraordinaires.",
      viewProjects: "Voir les Projets",
      getInTouch: "Me Contacter",
    },
    about: {
      title: "À",
      titleHighlight: "Propos",
      description:
        "Je suis un professionnel passionné par la création d'expériences numériques qui combinent un code propre avec un design impeccable. Avec des années d'expérience en développement et design, j'aide les marques et les entreprises à se démarquer dans le monde numérique.",
      development: {
        title: "Développement",
        description: "Expert en React, Next.js, TypeScript et Node.js",
      },
      design: {
        title: "Design",
        description: "Identité visuelle, branding et design pour les réseaux sociaux",
      },
      performance: {
        title: "Performance",
        description: "Focus sur l'optimisation et l'expérience utilisateur",
      },
      collaboration: {
        title: "Collaboration",
        description: "Travail d'équipe et communication efficace",
      },
    },
    skills: {
      title: "Mes",
      titleHighlight: "Compétences",
      subtitle: "Technologies et outils que je maîtrise",
      development: "Développement",
      design: "Design",
    },
    projects: {
      title: "Projets de",
      titleHighlight: "Développement",
      subtitle: "Certains de mes travaux les plus récents",
      all: "Tous",
      web: "Web",
      mobile: "Mobile",
      code: "Code",
      demo: "Démo",
      project1: {
        title: "Plateforme E-commerce",
        description: "Plateforme e-commerce complète avec Next.js, Stripe et PostgreSQL",
      },
      project2: {
        title: "Tableau de Bord Analytics",
        description: "Tableau de bord interactif avec graphiques en temps réel et visualisation de données",
      },
      project3: {
        title: "Application Mobile Fitness",
        description: "Application fitness avec suivi des exercices et nutrition",
      },
      project4: {
        title: "Page d'Atterrissage SaaS",
        description: "Page d'atterrissage moderne et responsive pour produit SaaS",
      },
    },
    contact: {
      title: "Prenez",
      titleHighlight: "Contact",
      subtitle: "Travaillons ensemble sur votre prochain projet",
      info: "Informations de Contact",
      email: "Email",
      phone: "Téléphone",
      location: "Localisation",
      available: "Disponible pour des Projets",
      availableText:
        "Je suis toujours ouvert à discuter de nouveaux projets, d'idées créatives ou d'opportunités de faire partie de votre vision.",
      availableNow: "Disponible maintenant",
      form: {
        name: "Nom",
        namePlaceholder: "Votre nom",
        email: "Email",
        emailPlaceholder: "votre@email.com",
        message: "Message",
        messagePlaceholder: "Parlez-moi de votre projet...",
        send: "Envoyer le Message",
      },
      footer: {
        rights: "Tous droits réservés.",
        built: "Construit avec Next.js et Tailwind CSS",
      },
    },
  },
  es: {
    nav: {
      home: "Inicio",
      about: "Sobre Mí",
      skills: "Habilidades",
      projects: "Proyectos",
      design: "Diseño",
      contact: "Contacto",
    },
    hero: {
      badge: "Desarrollador & Diseñador",
      title: "Creando experiencias",
      titleHighlight: "digitales únicas",
      description:
        "Desarrollador full-stack y diseñador especializado en identidad visual y redes sociales. Transformo ideas en productos digitales extraordinarios.",
      viewProjects: "Ver Proyectos",
      getInTouch: "Contactar",
    },
    about: {
      title: "Sobre",
      titleHighlight: "Mí",
      description:
        "Soy un profesional apasionado por crear experiencias digitales que combinan código limpio con diseño impecable. Con años de experiencia en desarrollo y diseño, ayudo a marcas y empresas a destacarse en el mundo digital.",
      development: {
        title: "Desarrollo",
        description: "Experto en React, Next.js, TypeScript y Node.js",
      },
      design: {
        title: "Diseño",
        description: "Identidad visual, branding y diseño para redes sociales",
      },
      performance: {
        title: "Rendimiento",
        description: "Enfoque en optimización y experiencia del usuario",
      },
      collaboration: {
        title: "Colaboración",
        description: "Trabajo en equipo y comunicación efectiva",
      },
    },
    skills: {
      title: "Mis",
      titleHighlight: "Habilidades",
      subtitle: "Tecnologías y herramientas que domino",
      development: "Desarrollo",
      design: "Diseño",
    },
    projects: {
      title: "Proyectos de",
      titleHighlight: "Desarrollo",
      subtitle: "Algunos de mis trabajos más recientes",
      all: "Todos",
      web: "Web",
      mobile: "Móvil",
      code: "Código",
      demo: "Demo",
      project1: {
        title: "Plataforma E-commerce",
        description: "Plataforma completa de e-commerce con Next.js, Stripe y PostgreSQL",
      },
      project2: {
        title: "Panel de Analytics",
        description: "Panel interactivo con gráficos en tiempo real y visualización de datos",
      },
      project3: {
        title: "App Móvil de Fitness",
        description: "App de fitness con seguimiento de ejercicios y nutrición",
      },
      project4: {
        title: "Landing Page SaaS",
        description: "Landing page moderna y responsive para producto SaaS",
      },
    },
    contact: {
      title: "Ponte en",
      titleHighlight: "Contacto",
      subtitle: "Trabajemos juntos en tu próximo proyecto",
      info: "Información de Contacto",
      email: "Email",
      phone: "Teléfono",
      location: "Ubicación",
      available: "Disponible para Proyectos",
      availableText:
        "Siempre estoy abierto a discutir nuevos proyectos, ideas creativas u oportunidades de ser parte de tu visión.",
      availableNow: "Disponible ahora",
      form: {
        name: "Nombre",
        namePlaceholder: "Tu nombre",
        email: "Email",
        emailPlaceholder: "tu@email.com",
        message: "Mensaje",
        messagePlaceholder: "Cuéntame sobre tu proyecto...",
        send: "Enviar Mensaje",
      },
      footer: {
        rights: "Todos los derechos reservados.",
        built: "Construido con Next.js y Tailwind CSS",
      },
    },
  },
}

export type Language = keyof typeof translations
export type TranslationKey = keyof typeof translations.en
