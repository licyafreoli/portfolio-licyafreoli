"use client"

import { useEffect, useRef } from "react"
import Hero from "@/components/hero"
import About from "@/components/about"
import Skills from "@/components/skills"
import Projects from "@/components/projects"
import DesignWork from "@/components/design-work"
import Contact from "@/components/contact"
import Navigation from "@/components/navigation"
import CursorEffect from "@/components/cursor-effect"

export default function Portfolio() {
  const sectionsRef = useRef<HTMLElement[]>([])

  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: "0px 0px -100px 0px",
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("animate-in")
        }
      })
    }, observerOptions)

    sectionsRef.current.forEach((section) => {
      if (section) observer.observe(section)
    })

    return () => observer.disconnect()
  }, [])

  const addToRefs = (el: HTMLElement | null) => {
    if (el && !sectionsRef.current.includes(el)) {
      sectionsRef.current.push(el)
    }
  }

  return (
    <main className="relative cursor-none">
      <CursorEffect />

      <Navigation />

      <section
        ref={addToRefs}
        className="opacity-0 transition-all duration-1000 ease-out translate-y-10 [&.animate-in]:opacity-100 [&.animate-in]:translate-y-0"
      >
        <Hero />
      </section>

      <section
        ref={addToRefs}
        id="sobre"
        className="opacity-0 transition-all duration-1000 ease-out translate-y-10 [&.animate-in]:opacity-100 [&.animate-in]:translate-y-0"
      >
        <About />
      </section>

      <section
        ref={addToRefs}
        id="habilidades"
        className="opacity-0 transition-all duration-1000 ease-out translate-y-10 [&.animate-in]:opacity-100 [&.animate-in]:translate-y-0"
      >
        <Skills />
      </section>

      <section
        ref={addToRefs}
        id="projetos"
        className="opacity-0 transition-all duration-1000 ease-out translate-y-10 [&.animate-in]:opacity-100 [&.animate-in]:translate-y-0"
      >
        <Projects />
      </section>

      <section
        ref={addToRefs}
        id="design"
        className="opacity-0 transition-all duration-1000 ease-out translate-y-10 [&.animate-in]:opacity-100 [&.animate-in]:translate-y-0"
      >
        <DesignWork />
      </section>

      <section
        ref={addToRefs}
        id="contato"
        className="opacity-0 transition-all duration-1000 ease-out translate-y-10 [&.animate-in]:opacity-100 [&.animate-in]:translate-y-0"
      >
        <Contact />
      </section>
    </main>
  )
}
